<?php
    define("DB_SERVERNAME", "localhost");
    define("DB_DBNAME", "gouden_draak");
    define("DB_USERNAME", "root");
    define("DB_PASSWORD", "");
?>