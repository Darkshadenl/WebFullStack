<div id="menuPage" class="hidden">
    <img width="100%" src="..\paginas\menukaarten\restaurant-menukaart-1-2.jpg">
    <img width="100%" src="..\paginas\menukaarten\restaurant-menukaart-1.jpg">
</div>